//
//  VarunCardApp.swift
//  VarunCard
//
//  Created by Varun Ambulgekar on 17/10/24.
//

import SwiftUI

@main
struct VarunCardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
