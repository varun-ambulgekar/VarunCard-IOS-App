//
//  ContentView.swift
//  VarunCard
//
//  Created by Varun Ambulgekar on 17/10/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            Color(red: 0.45, green: 0.73, blue: 1.00, opacity: 1.00)
            
            VStack {
                Image("varun")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 350, height: 350)
                    .clipShape(Circle())
                    .shadow(radius: 10)
                    .overlay(
                        Circle().stroke(Color.white, lineWidth: 5 )
                    )
                
                
                Text("Varun Ambulgekar")
                    .font(Font.custom("Agdasima-Regular", size: 40))
                    .bold()
                    .foregroundColor(.white)
                
                Text("App Developer")
                    .foregroundColor(.white)
                    .font(.subheadline)
                
                Divider()
                
                RoundedRectangle(cornerRadius: 25)
                    .frame(width: 300,height: 50 )
                    .foregroundColor(.white)
                    .overlay(HStack{
                        Image(systemName: "phone.fill").foregroundColor(.blue)
                        Text("+91 8999493253")
                    })
                RoundedRectangle(cornerRadius: 25)
                    .frame(width: 300,height: 50 )
                    .foregroundColor(.white)
                    .overlay(HStack{
                        Image(systemName: "envelope.fill").foregroundColor(.blue)
                        Text("varunambulgkear700@gmail.com")
                    })
                    .padding(.all)
                    
            }
        }
            
        }
    }


#Preview {
    ContentView()
}
